<?php
#Application name: PhpCollab
#Status page: 0
echo "</td></tr></table>";

echo "</td>
</tr>
</table>

</body>
</html>";
?>