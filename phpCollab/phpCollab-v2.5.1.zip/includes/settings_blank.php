<?php
#Application name: PhpCollab
#Status page: 2
#Path by root: ../includes/settings_blank.php
?>