<?php
#Application name: PhpCollab
#Status page: 0
	# Mantis - a php based bugtracking system
	# Copyright (C) 2000 - 2002  Kenzaburo Ito - kenito@300baud.org
	# This program is distributed under the terms and conditions of the GPL
	# See the files README and LICENSE for details

  	require( "../mantis/constant_inc.php" );
	require( "../mantis/config_inc.php" );
	require( "../mantis/core_database_API.php" );
	require( "../mantis/core_user_API.php" );
	require( "../mantis/core_print_API.php" );
	require( "../mantis/core_helper_API.php" );
	require( "../mantis/core_proj_user_API.php" );
	
	# --------------------
?>