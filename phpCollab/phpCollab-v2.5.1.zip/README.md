[![Stories in Ready](https://badge.waffle.io/phpcollab/v2.x.png?label=ready&title=Ready)](https://waffle.io/phpcollab/v2.x)
[![Gitter](https://badges.gitter.im/Join Chat.svg)](https://gitter.im/phpcollab/v2.x?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)
phpCollab 2.x
===

This is the old v2.x code for phpCollab migrated from [SourceForge](http://sourceforge.com/ "Title"). 

If you'd like to keep tabs on the development, or better yet help out, all work is currently being done in the [phpCollab](https://github.com/phpcollab/phpcollab/) repository.
