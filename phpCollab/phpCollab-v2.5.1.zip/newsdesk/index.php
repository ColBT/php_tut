<?php
#Application name: PhpCollab
#Status page: 2
#Path by root: ../newsdesk/index.php

header("Location:../index.php");
exit;
?>