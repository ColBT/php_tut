<?php
$topicNote = array(1 => "Telefonsamtale", 2 => "Konferencenoter", 3 => "Generelle Noter");

$phaseArraySets = array(
	#Define the names of your phase sets
	"sets" => array(1 => "Website", 2 => "CD"),
	#List the indervitual items within each phase set.
	#Website Set
	"1" => array(0 => "Planl�gning", 1 => "Design", 2 => "Testning", 3 => "Sign-off", 4 => "Produktion"),
	#CD Set
	"2" => array(0 => "Planl�gning", 1 => "Design", 2 => "Testning", 3 => "Produktion")
);

?>
