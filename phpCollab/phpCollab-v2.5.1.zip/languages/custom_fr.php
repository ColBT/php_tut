<?php

$topicNote = array(1 => "Conversation téléphonique", 2 => "Note de réunion", 3 => "Note générale");

$phaseArraySets = array(
	#Définir ici les libellés des phases
	"sets" => array(1 => "Site web", 2 => "CD-ROM"),
	#Lister ci-dessous les étapes individuelles pour chaque jeu de phases
	#Site Web
	"1" => array(0 => "Conception", 1 => "Prototypage", 2 => "Réalisation", 3 => "Expérimentation", 4 => "Recette",5=>"Production"),
	#CD-ROM
	"2" => array(0 => "Conception", 1 => "Prototypage", 2 => "Réalisation", 3 => "Expérimentation",4 => "Production")
);
?>