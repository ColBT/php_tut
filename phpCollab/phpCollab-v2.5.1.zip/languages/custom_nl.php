<?php
 $topicNote = array(1 => "Telefoongesprek", 2 => "Notulen", 3 => "Aantekeningen");

$phaseArraySets = array(
   #Definieer de namen van de fase sets
   "sets" => array(1 => "Website", 2 => "CD"),
   #Toon de individuele items in elke fase set.
   #Website Set
   "1" => array(0 => "Planning", 1 => "Ontwerp", 2 => "Testen", 3 => "Afronding", 4 => "Productie"),
   #CD Set
   "2" => array(0 => "Planning", 1 => "Ontwerp", 2 => "Testen", 3 => "Productie")
);

?> 