<?php
$topicNote = array(1 => "Telefongespr&auml;ch", 2 => "Konferenz Notizen", 3 => "Allgemeine Notizen");

$phaseArraySets = array(
	#Define the names of your phase sets
	"sets" => array(1 => "Website", 2 => "CD"),
	#List the indervitual items within each phase set.
	#Website Set
	"1" => array(0 => "Planung", 1 => "Design", 2 => "Test", 3 => "Freigabe", 4 => "Produktion"),
	#CD Set
	"2" => array(0 => "Planung", 1 => "Design", 2 => "Test", 3 => "Produktion")
);

?>