<?php
$topicNote = array(1 => "Telefon Samtale", 2 => "Konferanse Notat", 3 => "Generelle Notat");

$phaseArraySets = array(
#Define the names of your phase sets
"sets" => array(1 => "Webside", 2 => "CD"),
#List the indervitual items within each phase set.
#Website Set
"1" => array(0 => "Planlegging", 1 => "Design", 2 => "Testing", 3 => "Avslutt", 4 => "Produksjon"),
#CD Set
"2" => array(0 => "Planlegging", 1 => "Design", 2 => "Testing", 3 => "Produksjon")
);
 

?>