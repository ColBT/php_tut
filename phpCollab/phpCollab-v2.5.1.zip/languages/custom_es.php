<?php
$topicNote = array(1 => "Conversaci�n Telef�nica", 2 => "Notas de Conferencia", 3 => "Notas Generales");

$phaseArraySets = array(
		#Define the names of your phase sets
		"sets" => array(1 => "Pagina Web", 2 => "CD"),
		#List the indervitual items within each phase set.
		#Website Set
		"1" => array(0 => "Planificaci�n", 1 => "Dise�o", 2 => "Pruebas", 3 => "Cerrado", 4 => "Producci�n"),
		
		#CD Set
		"2" => array(0 => "Planificaci�n", 1 => "Dise�o", 2 => "Pruebas", 3 => "Producci�n")
);
?>