<?php
#Application name: PhpCollab
#Status page: 2
#Path by root: ../languages/custom_pt-br.php

//translator(s): Poorlyte <poorlyte@yahoo.com> (All Versions))

$topicNote = array(1 => "Conversa Telef�nica", 2 => "Notas de Confer�ncia", 3 => "Notas Gerais");

$phaseArraySets = array(
	#Define the names of your phase sets
	"sets" => array(1 => "Website", 2 => "CD"),
	#List the indervitual items within each phase set.
	#Website Set
	"1" => array(0 => "Planejamento", 1 => "Design", 2 => "Testes", 3 => "T�rmino", 4 => "Produ��o"),
	#CD Set
	"2" => array(0 => "Planejamento", 1 => "Design", 2 => "Testes", 3 => "Produ��o")
);

?>