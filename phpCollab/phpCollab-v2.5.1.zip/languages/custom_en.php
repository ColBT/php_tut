<?php
$topicNote = array(1 => "Phone Conversation", 2 => "Conference Notes", 3 => "General Notes");

$phaseArraySets = array(
	#Define the names of your phase sets
	"sets" => array(1 => "Website", 2 => "CD"),
	#List the indervitual items within each phase set.
	#Website Set
	"1" => array(0 => "Planning", 1 => "Design", 2 => "Testing", 3 => "Sign-off", 4 => "Production"),
	#CD Set
	"2" => array(0 => "Planning", 1 => "Design", 2 => "Testing", 3 => "Production")
);

?>