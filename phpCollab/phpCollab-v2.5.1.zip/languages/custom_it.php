<?php
$topicNote = array(1 => "Conversazione Telefonica", 2 => "Appunti Conferenza", 3 => "Appunti vari");

$phaseArraySets = array(
	#Define the names of your phase sets
	"sets" => array(1 => "Website", 2 => "CD"),
	#List the indervitual items within each phase set.
	#Website Set
	"1" => array(0 => "Pianificazione", 1 => "Design", 2 => "Testing", 3 => "Chiusura", 4 => "Produzione"),
	#CD Set
	"2" => array(0 => "Pianificazione", 1 => "Design", 2 => "Testing", 3 => "Produzione")
);

?>